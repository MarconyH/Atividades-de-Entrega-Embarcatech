#ifndef BIG_STRING_DRAWER_H
#define BIG_STRING_DRAWER_H

#include <stdint.h>

void draw_big_string_aligned_right(uint8_t *ssd, int y, const char *str);

#endif