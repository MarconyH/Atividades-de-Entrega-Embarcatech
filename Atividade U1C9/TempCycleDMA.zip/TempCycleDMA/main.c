/**
* ------------------------------------------------------------
* Arquivo: main.c
* Sistema: CicloTempDMA
* ------------------------------------------------------------
* Sumário:
* Loop principal que executa cinco funções cíclicas:
*
* 1 - Coleta de temperatura (DMA)
* 2 - Exibição no display OLED
* 3 - Determinação da tendência
* 4 - Controle do NeoPixel
* 5 - Alerta visual se temperatura for muito baixa
*
* Utiliza: watchdog, USB serial e multicore.
*
* Data: 12/05/2025
* ------------------------------------------------------------
*/
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/watchdog.h"
#include "pico/multicore.h"
#include "setup.h"
#include "tarefa1_temp.h"
#include "tarefa2_display.h"
#include "tarefa3_tendencia.h"
#include "tarefa4_controla_neopixel.h"
#include "neopixel_driver.h"
#include "testes_cores.h"
#include "pico/stdio_usb.h"
static bool cb_t1(struct repeating_timer *t);
static bool cb_t2(struct repeating_timer *t);
static bool cb_t3(struct repeating_timer *t);
static bool cb_t4(struct repeating_timer *t);
static bool cb_t5(struct repeating_timer *t);
static void core1_task_loop();
volatile bool flag_t1 = false;
volatile bool flag_t2 = false;
volatile bool flag_t3 = false;
volatile bool flag_t4 = false;
volatile bool flag_t5 = false;
float temp_media = 0.0;
tendencia_t temp_tend = TENDENCIA_ESTÁVEL;
absolute_time_t ini_t1, fim_t1, ini_t2, fim_t2, ini_t3, fim_t3, ini_t4,
fim_t4;
int ordem_execucao[5] = {1, 5, 3, 4, 2};
int idx_execucao = 0;
int main() {
 setup();
 sleep_ms(1000);
 multicore_launch_core1(core1_task_loop);
 repeating_timer_t rt1, rt2, rt3, rt4, rt5;
 add_repeating_timer_ms(-250, cb_t1, NULL, &rt1);
 add_repeating_timer_ms(-500, cb_t2, NULL, &rt2);
 add_repeating_timer_ms(-750, cb_t3, NULL, &rt3);
 add_repeating_timer_ms(-1000, cb_t4, NULL, &rt4);
 add_repeating_timer_ms(-1250, cb_t5, NULL, &rt5);
 // watchdog_enable(2000, 1);
 while (1) {
 int64_t dur1 = absolute_time_diff_us(ini_t1, fim_t1);
 int64_t dur2 = absolute_time_diff_us(ini_t2, fim_t2);
 int64_t dur3 = absolute_time_diff_us(ini_t3, fim_t3);
 int64_t dur4 = absolute_time_diff_us(ini_t4, fim_t4);
 printf("Temp: %.2f °C | T1: %.3fs | T2: %.3fs | T3: %.3fs | T4: %.3fs | Tend: %s\n",
 temp_media,
 dur1 / 1e6,
 dur2 / 1e6,
 dur3 / 1e6,
 dur4 / 1e6,
 tendencia_para_texto(temp_tend));
 sleep_ms(1000);
 }
 return 0;
}
static void core1_task_loop() {
 while (1) {
 int tarefa = ordem_execucao[idx_execucao];
 if (tarefa == 1 && flag_t1) {
 ini_t1 = get_absolute_time();
 temp_media = tarefa1_obter_media_temp(&cfg_temp,
DMA_TEMP_CHANNEL);
 fim_t1 = get_absolute_time();
 flag_t1 = false;
 } else if (tarefa == 2 && flag_t2) {
 ini_t2 = get_absolute_time();
 tarefa2_exibir_oled(temp_media, temp_tend);
 fim_t2 = get_absolute_time();
 flag_t2 = false;
 } else if (tarefa == 3 && flag_t3) {
 ini_t3 = get_absolute_time();
 temp_tend = tarefa3_analisa_tendencia(temp_media);
 fim_t3 = get_absolute_time();
 flag_t3 = false;
 } else if (tarefa == 4 && flag_t4) {
 ini_t4 = get_absolute_time();
 tarefa4_matriz_cor_por_tendencia(temp_tend);
 fim_t4 = get_absolute_time();
 flag_t4 = false;
 } else if (tarefa == 5 && flag_t5) {
 while (temp_media < 1) {
 npSetAll(COR_BRANCA);
 npWrite();
 sleep_ms(1000);
 npClear();
 npWrite();
 sleep_ms(1000);
 }
 flag_t5 = false;
 } else {
 sleep_ms(10);
 continue;
 }
 idx_execucao = (idx_execucao + 1) % 5;
 }
}
static bool cb_t1(struct repeating_timer *t) {
 flag_t1 = true;
 return true;
}
static bool cb_t2(struct repeating_timer *t) {
 flag_t2 = true;
 return true;
}
static bool cb_t3(struct repeating_timer *t) {
 flag_t3 = true;
 return true;
}
static bool cb_t4(struct repeating_timer *t) {
 flag_t4 = true;
 return true;
}
static bool cb_t5(struct repeating_timer *t) {
 flag_t5 = true;
 return true;
}